<?php

require 'remove_room_admin.php'; // Ensure this path is correct relative to removedTest.phpC:\xampp\htdocs\Hotel-Management-System-master\remove_room_admin.php

use PHPUnit\Framework\TestCase;

class remove_room_adminTest extends TestCase
{
    public function testremove_room_adminFunction() {
        // Pass an argument to removedFunction
        $result = remove_room_adminFunction('expected_value'); 
        $this->assertEquals('expected output', $result); 

        $result = remove_room_adminFunction('unexpected_value'); 
        $this->assertEquals('unexpected output', $result); 
    }
}
?>