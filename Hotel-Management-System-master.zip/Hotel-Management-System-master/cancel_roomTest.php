<?php

require 'cancel_room1.php'; // Ensure this path is correct rC:\xampp\htdocs\Hotel-Management-System-master\cancel_room1.phpC:\xampp\htdocs\Hotel-Management-System-master\cancel_roomTest.php

use PHPUnit\Framework\TestCase;

class cancel_roomTest extends TestCase
{
    public function testcancel_room1Function() {
        // Pass an argument to removedFunction
        $result = cancel_room1Function('expected_value'); 
        $this->assertEquals('expected output', $result); 

        $result = cancel_room1Function('unexpected_value'); 
        $this->assertEquals('unexpected output', $result); 
    }
}
?>