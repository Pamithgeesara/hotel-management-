<?php

require 'index.php'; // Ensure this path is correct relative to removedTest.phpC:\xampp\htdocs\Hotel-Management-System-master\index.php

use PHPUnit\Framework\TestCase;

class indexTest extends TestCase
{
    public function testindexFunction() {
        // Pass an argument to removedFunction
        $result = indexFunction('expected_value'); 
        $this->assertEquals('expected output', $result); 

        $result = indexFunction('unexpected_value'); 
        $this->assertEquals('unexpected output', $result); 
    }
}
?>